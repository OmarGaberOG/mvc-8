﻿global using AutoMapper;
global using AutoMapper.QueryableExtensions;
global using Demo.BLL.DataTransferObjects.Employees;
global using Demo.DataAccess.Models;
global using Demo.DataAccess.Repositories;
global using Microsoft.EntityFrameworkCore;