﻿namespace Demo.BLL;
public class AssemblyReference;