﻿namespace Demo.DataAccess.Models.Enums;
public enum EmployeeType
{
    FullTime = 1,
    PartTime = 2
}
