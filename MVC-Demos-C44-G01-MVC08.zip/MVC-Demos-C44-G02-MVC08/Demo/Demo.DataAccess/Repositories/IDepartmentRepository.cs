﻿namespace Demo.DataAccess.Repositories;
public interface IDepartmentRepository : IRepository<Department>
{


}
